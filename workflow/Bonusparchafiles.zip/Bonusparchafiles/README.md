# PaRChA
Scripts to format, name, tag and upload OCRed material of the *Pamphlet Repository for Changing Activism* (PaRChA) and its metadata. PaRChA is a repository of pamphlets, posters, leaflets, manifestos, reports, letters and press releases produced by Indian student organisations of national and regional parties over four decades (1973–2019).
