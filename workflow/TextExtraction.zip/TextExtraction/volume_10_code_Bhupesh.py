# Last edit on 23rd May'20 at 14:42 pm

from bs4 import BeautifulSoup
import docx
import re
import os
from time import strptime, strftime
import random
import pandas as pd
#import docx2txt

f = open('volume_10.html',mode = 'rb')
soup = BeautifulSoup(f, 'lxml')
search_result = soup.find_all('span',{'class':'cls_032'})
pre_speech_data= [span.get_text() for span in search_result]
count=1
for i in range(len(pre_speech_data)):
	if(pre_speech_data[i][0]=="*"):
		pre_speech_data[i]=" ".join([str(count),pre_speech_data[i]])
		count+=1

speech_and_writings=pre_speech_data
total_number_of_speeches = count
#print(speech_and_writings)

#with open("speech titles.txt","w") as titles:
#	for line in speech_and_writings:
#		if(line[0] in ["1","2","3","4","5","6","7","8","9"]):
#			titles.write("\n")
#		titles.write(line + "\n")


for script in soup(["script", "style"]):
	script.extract()    

# get text
text = soup.get_text()
data_1= text
with open("speech and debates data.txt","w",encoding="utf-8") as data:
	data.write(text)

search_result_dates = soup.find_all('span',{'class':'cls_034'})
dates_data = [span.get_text() for span in search_result_dates]
#print(type(dates_data))
count=1

final_dates=[]
for i in range(len(dates_data)):
	if(dates_data[i][0]=="*"):
		final_dates.append(dates_data[i])
		count+=1
#print(dates_data)


#print(final_dates)
#with open("dates.txt","w") as dt:
#	for line in final_dates:
#		if(line.find("January") or line.find("February") or line.find("March") or line.find("April") or line.find("May") or line.find("June") or line.find("July") or line.find("August") or line.find("September") or line.find("October") or line.find("November") or line.find("December")):
#			dt.write("\n")
#			#print(line)
#			dt.write(line)
#print(len(final_dates))

#bold=[]
doc = docx.Document('Volume_10.docx')
all_paragraphs = doc.paragraphs
str_arr=[]
exception_arr=[]
for i in range(1,473):
	str_arr.append(str(i))
	#exception_arr.append(str(i) + ".")


#print(str_arr)
for_extract=[]
all_titles=[]
r=[p.text for p in all_paragraphs]
for i in range(len(r)):
	if((r[i] in str_arr) or (r[i]=="10.")):
		all_titles.append(r[i+1])
		for_extract.append(i)
all_debates=[]

#print(all_titles)

count_num = 1
for i in range(total_number_of_speeches+2 , len(all_titles)):
	all_debates.append(str(count_num) + " " + all_titles[i])
	count_num+=1


#with open("debate titles.txt","w") as debate_titles:
#	for line in all_debates:
#		debate_titles.write(line + "\n")

with open("All titles.txt","w") as complete_titles:
	for line in all_titles:
		complete_titles.write(line + "\n")

# Naming the individual files according to the required format
dates_file = open("Dates(coding + manual).txt","r",encoding="utf-8")
list_of_dates = dates_file.read()
list11= re.findall(r'\d\d\s{1,}(?:January|February|March|April|May|June|July|August|September|October|November|December)\s{1,}\d{4}',list_of_dates)
#print(len(list11))
#print(list11)
new_result=[strftime('%Y%m%d',strptime(i,'%d %B %Y')) for i in list11]
#print(len(new_result))

final_dates1=[]
for i in range(len(new_result)):
	final_dates1.append("t" + new_result[i] + str(random.randint(100000,999999)))

#print(final_dates)


def create_files(filename,content):
	f=open(filename,'w',encoding='utf-8')
	for i in range(len(content)):
		if(( "WRITINGS" in content[i]) or ("DEBATES" in content[i]) or ("Debates" in content[i])):
			f.write(" " + "\n")
			#print(content[i])
		else:
			f.write(content[i]+ "\n")
	f.close()

# For speeches
for i in range(total_number_of_speeches+1):
	x1=for_extract[i]
	x2=for_extract[i+1]
	new_aa=r[x1:x2]
	name_of_file = final_dates1[i] + ".txt"
	create_files(name_of_file,new_aa)

#print(len(all_debates))
#print(for_extract)

# For debates
j=0
for i in range(total_number_of_speeches+2,len(for_extract)-1):
	#print(total_number_of_speeches+2)
	#print(len(all_titles)-1)
	j+=1
	x1=for_extract[i]
	x2=for_extract[i+1]
	#print(x1)
	#print(x2)
	new_aa=r[x1:x2]
	#print(new_aa)
	#print(r[for_extract[len(for_extract)]])
	name_of_file=final_dates1[i] + ".txt"
	create_files(name_of_file,new_aa)
	
# Code for csv started on 28th May'20
loc=[]
year=[]
month=[]
day=[]
period=[]
for i in range(len(final_dates1)):
	loc.append("ambedkar")
	year.append(final_dates1[i][1:5])
	month.append(final_dates1[i][1:7])
	day.append(final_dates1[i][1:9])
	
dict={'id':final_dates1, 'loc':loc , 'year':year , 'month':month , 'day':day}
data_frame = pd.DataFrame(dict)
data_frame.to_csv('Metadata_Volume10.csv')
