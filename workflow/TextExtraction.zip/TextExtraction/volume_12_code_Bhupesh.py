from bs4 import BeautifulSoup
import docx
import re
import os
from time import strptime, strftime
import random
import pandas as pd

doc=docx.Document('Volume_12.docx')
all_paragraphs= doc.paragraphs

f = open('volume_12.html',mode = 'rb')
soup = BeautifulSoup(f, 'lxml')
search_result = soup.find_all('span',{'class':'cls_025'})
all_tags= [span.get_text() for span in search_result]

chapter_tags=["Chapter 1.","Chapter 2.","Chapter 3.","Chapter 4.","Chapter 5.","Chapter 6.","Chapter 7.","Chapter 8."]

all_titles=[]
for i in range(len(all_tags)):
	if(all_tags[i] in chapter_tags):
		all_titles.append(all_tags[i+1])

#print(all_titles)
capital_titles=[]
for i in all_titles:
	capital_titles.append(i.upper())

num_of_chapters=len(capital_titles)
for_extract=["*" + title for title in capital_titles]
for_extract.append("PART VI")

#print(len(for_extract))
extract_indices=[]
r=[p.text for p in all_paragraphs]
for i in range(len(r)):
	if(r[i] in for_extract):
		extract_indices.append(i)
		#print(r[i])
#print(extract_indices)

str_1="***"
new_arr=[]
with open("Volume_12.txt","r") as f:
	line=f.readline()
	c=1
	while(line):
		if(str_1 in line):
			new_arr.append(c)
		line=f.readline()
		c+=1
#print(len(new_arr))


op_again=open("Volume_12.txt","r")
l=op_again.readlines()
#print(x1)
def create_files(filename,content):
	f=open(filename,'w',encoding='utf-8')
	for i in range(len(content)):
		if(( "WRITINGS" in content[i]) or ("DEBATES" in content[i]) or ("Debates" in content[i])):
			f.write(" " + "\n")
			#print(content[i])
		else:
			f.write(content[i]+ "\n")
	f.close()

dates_manual=["t19130101","t19140101","t19150101","t19301001","t19340101","t19460512","t19370101","t19370101","t19370101","t19370101","t19370101","t19370101","t19370101","t19370101","t19360101"]

final_dates=[]
for i in range(len(dates_manual)):
	final_dates.append(dates_manual[i] + str(random.randint(100000,999999)))

for i in range(len(new_arr)-1):
	j=0
	x1=new_arr[i]
	x2=new_arr[i+1]
	#print(x1)
	#print(x2)
	new_aa=l[x1:x2]
	#print(new_aa)
	#print(r[for_extract[len(for_extract)]])
	name_of_file=final_dates[i] + ".txt"
	#j+=1
	create_files(name_of_file,new_aa)


loc=[]
year=[]
month=[]
day=[]
period=[]
for i in range(len(final_dates)):
	loc.append("ambedkar")
	year.append(final_dates[i][1:5])
	month.append(final_dates[i][1:7])
	day.append(final_dates[i][1:9])
	
dict={'id':final_dates, 'loc':loc , 'year':year , 'month':month , 'day':day}
data_frame = pd.DataFrame(dict)
data_frame.to_csv('Metadata_Volume12.csv')