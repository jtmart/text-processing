from bs4 import BeautifulSoup
import docx
import re
import os
from time import strptime, strftime
import random
import pandas as pd

doc=docx.Document('Volume_15.docx')
all_paragraphs= doc.paragraphs

find_headings=[]
r=[p.text for p in all_paragraphs]
for i in range(1,70):
	find_headings.append("(" + str(i) + ")")
annexure=["A","B","C","D","E","F","G","H","I","J","K","L"]
for j in annexure:
	find_headings.append("(" + j + ")")
find_headings.append("INDEX")

extract_indices=[]
r=[p.text for p in all_paragraphs]
for i in range(len(r)):
	if(r[i] in find_headings):
		extract_indices.append(i)

extract_indices=extract_indices[:33] + extract_indices[35:]
new_arr=[]

for i in range(len(r)):
	if("pp." in r[i] or "Ibid" in r[i] or "p." in r[i]):
		new_arr.append(r[i])
list11=[]
for i in range(len(r)):
	list11.append(re.findall(r'[0-9]+(?:st|nd|th|rd)\s{1,}(?:January|February|March|April|May|June|July|August|September|October|November|December)\s{1,}\d{4}',r[i]))
#print(list11)

with open("Dates_Volume15.txt","w") as dt:
	for line in new_arr:
		dt.write("\n")
		dt.write(line)	

dates_file = open("Dates_Volume15(coding + manual).txt","r",encoding="utf-8")
list_of_dates = dates_file.read()
find_date= re.findall(r'\d\d\s{1,}(?:January|February|March|April|May|June|July|August|September|October|November|December)\s{1,}\d{4}',list_of_dates)

new_result=[strftime('%Y%m%d',strptime(i,'%d %B %Y')) for i in find_date]


final_dates1=[]
for i in range(len(new_result)):
	final_dates1.append("t" + new_result[i] + str(random.randint(100000,999999)))

#print(final_dates1)
#print(len(final_dates1))

def create_files(filename,content):
	f=open(filename,'w',encoding='utf-8')
	for i in range(len(content)):
		if(( "WRITINGS" in content[i]) or ("DEBATES" in content[i]) or ("Debates" in content[i]) or ("pp." in content[i]) or ("Ibid" in content[i]) or ("p." in content[i])):
			f.write(" " + "\n")
			#print(content[i])
		else:
			f.write(content[i]+ "\n")
	f.close()

for i in range(len(final_dates1)):
	j=0
	x1=extract_indices[i]
	x2=extract_indices[i+1]
	#print(x1)
	#print(x2)
	new_aa=r[x1:x2]
	#print(new_aa)
	#print(r[for_extract[len(for_extract)]])
	name_of_file=final_dates1[i] + ".txt"
	#j+=1
	create_files(name_of_file,new_aa)

loc=[]
year=[]
month=[]
day=[]
period=[]
for i in range(len(final_dates1)):
	loc.append("ambedkar")
	year.append(final_dates1[i][1:5])
	month.append(final_dates1[i][1:7])
	day.append(final_dates1[i][1:9])
	
dict={'id':final_dates1, 'loc':loc , 'year':year , 'month':month , 'day':day}
data_frame = pd.DataFrame(dict)
data_frame.to_csv('Metadata_Volume15.csv')